<?php
/*
 * Created on 2013-9-16
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */

/**
 * 简单打印数组的方法
 * Enter description here ...
 * @param $array
 */
function p($array,$str = false){
	dump($array,1,'<pre>',$str);
}


















?>