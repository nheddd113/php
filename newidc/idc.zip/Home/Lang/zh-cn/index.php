<?php
return array(
    'notWXZ'   => '(物)闲置',
    'notWXJ'   => '(物)下架',
    'notWSQ'   => '(物)申请',
    'notWYY'   => '(物)运营',
    'notWHOST' => '宿主机',
    'notXXZ'   => '(虚)闲置',
    'notXXJ'   => '(虚)下架',
    'notXSQ'   => '(虚)申请',
    'notXYY'   => '(虚)运营',

    'WXZ'      => '(物)闲置',
    'WXJ'      => '(物)下架',
    'WSQ'      => '(物)申请',
    'WYY'      => '(物)运营',
    'XXZ'      => '(虚)闲置',
    'XXJ'      => '(虚)下架',
    'XSQ'      => '(虚)申请',
    'XYY'      => '(虚)运营',
    'WHOST'    => '宿主机',
);
?>
