<?php
return array(
    "server_version"=>"服务端版本",
    "online_number" => "当前在线人数",
    "register_number" => "总注册人数",
    "client_version" => "客户端版本",  //卧龙吟专有
    "gamename" => "当前游戏名称",
    "build_time"=>"服务端打包时间",
    "server_time"=>"当前服务器时间",
    "lyingdragon"=>"卧龙吟",
    "memcache"=>'memcache',
    "dreamback"=>"葵花宝典",
    "warcraft"=>"战诗",
    "legendary"=>"梦回江湖",
    "q5"=>"女巫之刃",
    'server_id' => '服务器ID',
    'server_name' => '区服名称',
    'ipaddr' => '服务器IP地址',
    'error' => '错误',
    'server_number'=>"服务端版本",
    'comment'=>'内容',
);
?>