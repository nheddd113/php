<?php
class HosttemplateModel extends CommonModel{}
?>
