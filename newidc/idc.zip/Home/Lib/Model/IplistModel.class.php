<?php
class IplistModel extends CommonModel{
}
?>
