<?php
class OpsModel extends CommonModel{}
?>
