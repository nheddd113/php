<?php
return array(
	'app_begin' => array('CheckLang'),
);
?>