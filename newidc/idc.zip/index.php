<?php
/*
 * Created on 2013-9-16
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
define('APP_NAME', 'Home');
define('APP_PATH','./Home/');
define('APP_DEBUG',true);
require_once './ThinkPHP/ThinkPHP.php';
?>