<?php
return array(
	'DB_TYPE'=>'mysqli',
	'DB_HOST'=>'127.0.0.1',
	'DB_PWD'=>'123456',
	'DB_USER'=>'root',
	'DB_PORT'=>'',
	'DB_NAME' => 'newidc',
	'DB_PREFIX'=>'uqee_',
	'SESSION_TYPE'=> 'Db',
	'SESSION_EXPIRE'=>30 * 24 * 3600,
	'URL_MODEL'=>0,
	// 'TMPL_ACTION_ERROR' =>TMPL_PATH.'Public_success',
 //    'TMPL_ACTION_SUCCESS' =>TMPL_PATH.'Public_success',
	'TMPL_L_DELIM'=>'<{',
	'TMPL_R_DELIM'=>'}>',
	'TMPL_FILE_DEPR' => '_',
	'TMPL_TEMPLATE_SUFFIX'  => '.html',
);
?>
